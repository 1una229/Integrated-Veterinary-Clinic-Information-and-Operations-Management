package com.pawcare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PawcareApplication {
    public static void main(String[] args) {
        SpringApplication.run(PawcareApplication.class, args);
    }
}
